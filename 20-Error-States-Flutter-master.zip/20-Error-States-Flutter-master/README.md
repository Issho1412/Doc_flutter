# 20+ Error State For Android and iOS - Flutter

## [Watch it on YouTube](https://youtu.be/_yr_UpWemS8)

We design 21 error pages for your app it runs both Android and iOS because it builds with flutter. It contains almost all error pages like 404 page not found, No internet connection, File not found, also contain location access or camera access custom screen which provide you better user experience.

### Preview

![App UI](/ui.png)
