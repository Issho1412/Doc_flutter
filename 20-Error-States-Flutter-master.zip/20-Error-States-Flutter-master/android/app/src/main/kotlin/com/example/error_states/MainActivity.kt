package com.example.error_states

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
