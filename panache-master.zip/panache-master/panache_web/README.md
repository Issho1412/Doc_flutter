# Panache for your browser

[Building Flutter apps for the web](https://github.com/flutter/flutter/wiki/Building-a-web-application-with-Flutter)

```bash
flutter run -d chrome
```