//
//  Generated file. Do not edit.
//
import Foundation
import FlutterMacOS


func RegisterGeneratedPlugins(registry: FlutterPluginRegistry) {
}
