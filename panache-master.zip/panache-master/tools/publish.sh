cp -R panache_web/build/web/* ./docs/
cp -R panache_web/build/web/* ../017/panache_web/docs/
echo "COMPLETE !!!"