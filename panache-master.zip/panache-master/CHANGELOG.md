# Changelog

## 0.0.4

- support Dart 2.1 (thanks @csells)

## 0.0.3

- theme saving
- flutterial companion

## 0.0.2

- fixes for iOS layout

## 0.0.1

- basic colors and text theme preview
 