class File {
  File(String path);

  existsSync() {}
}
