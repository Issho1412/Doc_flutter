export 'button_theme_help.dart';
export 'global_theme_help.dart';

class HelpData {
  final String title;
  final String content;

  const HelpData(this.title, this.content);
}
