# panache_desktop

Panache MacOS

```bash
flutter run -d macos
```