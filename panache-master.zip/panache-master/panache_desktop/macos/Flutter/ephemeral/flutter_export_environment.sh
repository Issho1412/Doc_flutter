#!/bin/sh
# This is a generated file; do not edit or check into version control.
export "FLUTTER_ROOT=/Users/rxlabz/dev/tools/flutter"
export "FLUTTER_APPLICATION_PATH=/Users/rxlabz/projects/Panache/dev/panache/panache_desktop"
export "FLUTTER_TARGET=/Users/rxlabz/projects/Panache/dev/panache/panache_desktop/lib/main.dart"
export "FLUTTER_BUILD_DIR=build"
export "FLUTTER_FRAMEWORK_DIR=/Users/rxlabz/dev/tools/flutter/bin/cache/artifacts/engine/darwin-x64"
export "FLUTTER_BUILD_NAME=0.2.2"
export "FLUTTER_BUILD_NUMBER=0.2.2"
