abstract class LinkService {
  void open(String url);
}
