import 'package:flutter_test/flutter_test.dart';

void main() {
  group('A group of tests', () {
    setUp(() {});

    test('First Test', () {});
  });
}
